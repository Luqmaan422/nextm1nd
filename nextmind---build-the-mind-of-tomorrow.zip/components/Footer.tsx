
import React from 'react';
import { NAV_ITEMS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="py-16 border-t border-white/5 bg-brand-dark">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <a href="#home" className="text-3xl font-display font-black text-white flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-brand-accent rounded-xl flex items-center justify-center text-sm">NM</div>
              Next<span className="text-brand-accent">Mind</span>
            </a>
            <p className="text-slate-400 max-w-sm text-lg mb-6">
              Build the Mind of Tomorrow. Prepare for the skills that define the next decade.
            </p>
            <div className="flex gap-4">
              {['Twitter', 'Instagram', 'LinkedIn', 'YouTube'].map(social => (
                <a key={social} href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-400 hover:text-brand-accent hover:border-brand-accent transition-all">
                  <span className="sr-only">{social}</span>
                  <div className="w-4 h-4 rounded-sm bg-current opacity-50"></div>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h5 className="text-white font-bold mb-6">Explore</h5>
            <ul className="space-y-4">
              {NAV_ITEMS.map(item => (
                <li key={item.label}>
                  <a href={item.href} className="text-slate-400 hover:text-white transition-colors">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="text-white font-bold mb-6">Contact</h5>
            <ul className="space-y-4 text-slate-400">
              <li>hello@nextmind.edu</li>
              <li>+252 61 XXX XXXX</li>
              <li>Mogadishu, Somalia</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-sm">
          <p>© 2026 NextMind. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
