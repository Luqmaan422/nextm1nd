
import { GoogleGenAI } from "@google/genai";

// Fix: Initializing with process.env.API_KEY directly as per SDK requirements
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const askNextMindAI = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are the NextMind AI Assistant. 
        NextMind is a modern educational brand focused on Video Editing, AI, Digital Marketing, and Self-Development.
        Your goal is to answer questions about these topics concisely and professionally. 
        The target audience is Somali youth interested in tech. 
        You can speak both English and Somali. 
        Encourage users to register for NextMind courses.
        Keep answers short and futuristic.`,
        temperature: 0.7,
      },
    });
    // Fix: Accessing the .text property directly (not a method) as per SDK specifications
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to my neural network right now. Please try again later!";
  }
};
