
import React from 'react';
import { ChevronRight, Play } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-1/4 -left-20 w-64 h-64 bg-brand-accent/20 rounded-full blur-[120px] animate-pulse-slow"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-brand-neon/10 rounded-full blur-[140px] animate-pulse-slow delay-1000"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-white/10 text-xs font-bold text-brand-neon uppercase tracking-widest mb-8 animate-bounce">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-neon opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-neon"></span>
            </span>
            New Skills for 2026
          </div>
          
          <h1 className="text-5xl md:text-8xl font-display font-black text-white leading-tight mb-6 tracking-tight">
            Build the Mind of <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-brand-neon">Tomorrow.</span>
          </h1>

          <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            NextMind waa platform casri ah oo kuu diyaariya xirfadaha berri: 
            <span className="text-white font-semibold"> video editing, AI & tech, suuq-geyn, iyo horumarinta maskaxda </span> 
            si aad u noqoto qof xirfad leh oo mustaqbalka diyaar u ah.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href="#register" 
              className="group relative px-8 py-4 bg-white text-black font-bold rounded-full transition-all transform hover:scale-105 flex items-center gap-2 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-brand-accent to-brand-neon opacity-0 group-hover:opacity-10 transition-opacity"></div>
              Join NextMind
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#about" 
              className="px-8 py-4 glass text-white font-bold rounded-full border border-white/10 hover:border-brand-accent/50 transition-all flex items-center gap-2"
            >
              <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center">
                <Play className="w-3 h-3 fill-white" />
              </div>
              Explore Courses
            </a>
          </div>
        </div>
      </div>
      
      {/* Decorative Grid */}
      <div className="absolute inset-0 -z-10 opacity-10" 
           style={{ backgroundImage: 'radial-gradient(#ffffff 0.5px, transparent 0.5px)', backgroundSize: '40px 40px' }}>
      </div>
    </section>
  );
};

export default Hero;
