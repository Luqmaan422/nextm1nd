
import React from 'react';
import { Video, Cpu, Brain, ShieldCheck, TrendingUp } from 'lucide-react';
import { InterestArea, FeatureCard, NavItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#home' },
  { label: 'Why Us', href: '#about' },
  { label: 'Curriculum', href: '#learn' },
  { label: 'Register', href: '#register' },
];

export const FEATURES: FeatureCard[] = [
  {
    title: 'Video Editing',
    description: 'Master CapCut and professional storytelling techniques.',
    somaliDesc: 'Baro xirfadda CapCut iyo hababka casriga ah ee loo sameeyo muuqaallada tayada leh.',
    icon: <Video className="w-8 h-8 text-brand-accent" />,
  },
  {
    title: 'AI & No-Code Tools',
    description: 'Leverage AI tools for massive productivity gains.',
    somaliDesc: 'Isticmaal aaladaha AI si aad u kordhiso waxqabadkaaga iyo dakhligaaga.',
    icon: <Cpu className="w-8 h-8 text-brand-neon" />,
  },
  {
    title: 'Mindset & Discipline',
    description: 'Build the focus and drive needed for long-term success.',
    somaliDesc: 'Horumarinta maskaxda, anshaxa, iyo dhiirigelinta si aad guul u gaarto.',
    icon: <Brain className="w-8 h-8 text-brand-accent" />,
  },
  {
    title: 'Digital Self-Protection',
    description: 'Secure your online identity and data assets.',
    somaliDesc: 'Baro sidii aad isaga difaaci lahayd khataraha internet-ka ee xilligan.',
    icon: <ShieldCheck className="w-8 h-8 text-brand-neon" />,
  },
  {
    title: 'Selling & Marketing',
    description: 'Learn the psychology of sales and digital growth.',
    somaliDesc: 'Baro cilmi-nafsiga iibka iyo suuq-geynta casriga ah ee internet-ka.',
    icon: <TrendingUp className="w-8 h-8 text-brand-accent" />,
  },
];

export const LEARNING_MODULES = [
  {
    id: 1,
    title: 'Professional Video Editing',
    details: 'Transitions, color grading, sound design, and viral hook strategies.',
  },
  {
    id: 2,
    title: 'AI Productivity Suite',
    details: 'ChatGPT mastery, AI image generation, and automation workflows.',
  },
  {
    id: 3,
    title: 'Strategic Marketing',
    details: 'Personal branding, ad targeting, and funnel building.',
  },
  {
    id: 4,
    title: 'Personal Mastery',
    details: 'Deep work, habit formation, and emotional intelligence.',
  },
  {
    id: 5,
    title: 'Cyber Security Basics',
    details: 'Two-factor auth, social engineering awareness, and privacy tools.',
  },
];
