
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Curriculum from './components/Curriculum';
import Registration from './components/Registration';
import Community from './components/Community';
import Footer from './components/Footer';
import AIAssistant from './components/AIAssistant';

function App() {
  return (
    <div className="min-h-screen bg-brand-dark selection:bg-brand-accent/30 selection:text-white">
      <Header />
      
      <main>
        <Hero />
        <About />
        <Curriculum />
        <Registration />
        <Community />
      </main>

      <Footer />
      <AIAssistant />
    </div>
  );
}

export default App;
