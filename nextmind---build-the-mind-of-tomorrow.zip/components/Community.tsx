
import React from 'react';
import { Send, Youtube, ArrowRight } from 'lucide-react';

const Community: React.FC = () => {
  return (
    <section className="py-24">
      <div className="container mx-auto px-6">
        <div className="bg-gradient-to-br from-brand-accent/20 to-brand-neon/10 p-12 md:p-20 rounded-[48px] border border-white/10 text-center relative overflow-hidden">
          {/* Decorative shapes */}
          <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-br-full"></div>
          <div className="absolute bottom-0 right-0 w-32 h-32 bg-white/5 rounded-tl-full"></div>

          <h2 className="text-3xl md:text-5xl font-display font-black text-white mb-6">
            Join the NextMind Community
          </h2>
          <p className="text-slate-300 text-lg mb-12 max-w-2xl mx-auto">
            Join our learning community and grow with like-minded people. 
            Hormar ka gaar aduunka dhijitaalka ah adigoo helaya garab joogto ah.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a 
              href="https://t.me/nextmind" 
              target="_blank" 
              className="bg-[#229ED9] hover:bg-[#1E88BE] px-10 py-5 rounded-3xl text-white font-bold flex items-center gap-3 transition-all transform hover:scale-105"
            >
              <Send className="w-6 h-6" />
              Join Telegram
            </a>
            <a 
              href="https://youtube.com/nextmind" 
              target="_blank" 
              className="bg-[#FF0000] hover:bg-[#CC0000] px-10 py-5 rounded-3xl text-white font-bold flex items-center gap-3 transition-all transform hover:scale-105"
            >
              <Youtube className="w-6 h-6" />
              Follow on YouTube
            </a>
          </div>

          <div className="mt-16 flex items-center justify-center gap-4 text-slate-400 text-sm">
            <span>Weekly updates</span>
            <div className="w-1 h-1 rounded-full bg-slate-600"></div>
            <span>No spam</span>
            <div className="w-1 h-1 rounded-full bg-slate-600"></div>
            <span>Free resources</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Community;
