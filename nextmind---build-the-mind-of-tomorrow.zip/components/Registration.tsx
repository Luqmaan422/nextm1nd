
import React, { useState } from 'react';
import { Send, CheckCircle } from 'lucide-react';
import { InterestArea } from '../types';

const Registration: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    contact: '',
    interest: InterestArea.VIDEO_EDITING
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setTimeout(() => {
      setSubmitted(true);
    }, 800);
  };

  if (submitted) {
    return (
      <section id="register" className="py-24 bg-brand-dark">
        <div className="container mx-auto px-6 text-center">
          <div className="glass max-w-2xl mx-auto p-12 rounded-[32px] border border-brand-neon/30 animate-scale-in">
            <div className="w-20 h-20 bg-brand-neon/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-brand-neon" />
            </div>
            <h3 className="text-3xl font-display font-bold text-white mb-4">Registration Successful!</h3>
            <p className="text-slate-400 mb-8">
              Thank you for joining NextMind. We will contact you soon through your provided email or phone number.
            </p>
            <button 
              onClick={() => setSubmitted(false)}
              className="text-brand-accent font-bold hover:underline"
            >
              Register another person
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="register" className="py-24 bg-brand-dark">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto flex flex-col lg:flex-row gap-16 items-center">
          <div className="flex-1">
            <h2 className="text-brand-neon font-bold uppercase tracking-widest text-sm mb-4">Get Started</h2>
            <h3 className="text-4xl md:text-5xl font-display font-bold text-white leading-tight mb-6">
              Ready to Upgrade <br /> Your Career?
            </h3>
            <p className="text-slate-400 text-lg mb-8 leading-relaxed">
              Buuxi foomka si aad u bilowdo safarkaaga NextMind. 
              Waxaan kugu soo wargelin doonaa casharrada bilaashka ah iyo koorsooyinka cusub.
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-6 h-6 rounded-full bg-brand-neon/20 flex items-center justify-center text-brand-neon text-xs">✓</div>
                <span>Free Introductory Workshops</span>
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-6 h-6 rounded-full bg-brand-neon/20 flex items-center justify-center text-brand-neon text-xs">✓</div>
                <span>Private Discord/Telegram Access</span>
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-6 h-6 rounded-full bg-brand-neon/20 flex items-center justify-center text-brand-neon text-xs">✓</div>
                <span>Curated Industry Resources</span>
              </div>
            </div>
          </div>

          <div className="flex-1 w-full max-w-md">
            <div className="glass p-8 md:p-10 rounded-[40px] border border-white/10 shadow-2xl relative">
              {/* Form header */}
              <div className="mb-8">
                <h4 className="text-2xl font-bold text-white mb-2">Registration</h4>
                <div className="h-1 w-12 bg-brand-accent rounded-full"></div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Full Name</label>
                  <input 
                    required
                    type="text" 
                    placeholder="Enter your name"
                    className="w-full bg-brand-dark/50 border border-white/10 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent transition-all"
                    value={formData.fullName}
                    onChange={e => setFormData({...formData, fullName: e.target.value})}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Email or Phone Number</label>
                  <input 
                    required
                    type="text" 
                    placeholder="example@email.com or +252..."
                    className="w-full bg-brand-dark/50 border border-white/10 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent transition-all"
                    value={formData.contact}
                    onChange={e => setFormData({...formData, contact: e.target.value})}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Area of Interest</label>
                  <select 
                    className="w-full bg-brand-dark/50 border border-white/10 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-brand-accent transition-all appearance-none cursor-pointer"
                    value={formData.interest}
                    onChange={e => setFormData({...formData, interest: e.target.value as InterestArea})}
                  >
                    {Object.values(InterestArea).map(area => (
                      <option key={area} value={area} className="bg-brand-surface text-white">{area}</option>
                    ))}
                  </select>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-brand-accent hover:bg-purple-600 text-white font-bold py-5 rounded-2xl transition-all flex items-center justify-center gap-3 group shadow-lg shadow-purple-900/20"
                >
                  Register Now
                  <Send className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Registration;
