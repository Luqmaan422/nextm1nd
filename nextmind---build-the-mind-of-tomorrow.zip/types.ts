
// Fix: Added React import to resolve the React namespace error
import React from 'react';

export enum InterestArea {
  VIDEO_EDITING = 'Video Editing',
  AI_TECH = 'AI & Tech',
  MARKETING_SELLING = 'Marketing & Selling',
  SELF_DEVELOPMENT = 'Self-Development'
}

export interface RegistrationFormData {
  fullName: string;
  contact: string;
  interest: InterestArea;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface FeatureCard {
  title: string;
  description: string;
  icon: React.ReactNode;
  somaliDesc?: string;
}
