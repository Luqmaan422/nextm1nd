
import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { LEARNING_MODULES } from '../constants';

const Curriculum: React.FC = () => {
  return (
    <section id="learn" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="glass p-8 md:p-16 rounded-[40px] border border-white/10 relative overflow-hidden">
          {/* Accent decoration */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-brand-neon/10 blur-[80px] -mr-32 -mt-32"></div>

          <div className="max-w-3xl">
            <h2 className="text-4xl font-display font-bold text-white mb-8">What You Will Learn</h2>
            <p className="text-slate-400 mb-12">
              Our curriculum is designed to be practical, updated, and results-oriented. 
              No fluff, only what works in 2026.
            </p>

            <div className="space-y-6">
              {LEARNING_MODULES.map((module) => (
                <div key={module.id} className="flex gap-6 items-start group">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-brand-accent/20 flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-6 h-6 text-brand-accent" />
                  </div>
                  <div>
                    <h5 className="text-xl font-bold text-white mb-1 group-hover:text-brand-accent transition-colors">
                      {module.title}
                    </h5>
                    <p className="text-slate-400 text-sm">
                      {module.details}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center gap-8">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <img 
                  key={i} 
                  src={`https://picsum.photos/100/100?random=${i}`} 
                  alt="Student" 
                  className="w-12 h-12 rounded-full border-2 border-brand-dark object-cover"
                />
              ))}
              <div className="w-12 h-12 rounded-full border-2 border-brand-dark bg-brand-surface flex items-center justify-center text-xs font-bold text-white">
                +1.2k
              </div>
            </div>
            <p className="text-slate-300 text-sm font-medium">
              Join 1,200+ students already mastering the future.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Curriculum;
